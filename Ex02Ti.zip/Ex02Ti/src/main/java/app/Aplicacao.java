package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;
import dao.DAO;
import dao.UsuarioDAO;
import model.Usuario;

import static java.lang.Integer.parseInt;

public class Aplicacao {
    public static BufferedReader leia = new BufferedReader (new InputStreamReader(System.in));
    public static int menu() throws IOException {
        int opcao;
        String linha;
        System.out.println("[0] Sair\n[1] Inserir\n[2] Ler\n[3] Atualizar\n[5] Deletar");
        linha = leia.readLine();
        opcao = parseInt(linha);
        return opcao;
    }
    public static void main(String[] args) throws Exception {
        int opcao = menu();

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        System.out.println("\n\n==== Inserir usuário === ");
        Usuario usuario = new Usuario(11, "pablo", "pablo",'M');
        if(usuarioDAO.insert(usuario) == true) {
            System.out.println("Inserção com sucesso -> " + usuario.toString());
        }

        System.out.println("\n\n==== Testando autenticação ===");
        System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", "pablo"));

        System.out.println("\n\n==== Mostrar usuários do sexo masculino === ");
        List<Usuario> usuarios = usuarioDAO.getSexoMasculino();
        for (Usuario u: usuarios) {
            System.out.println(u.toString());
        }

        System.out.println("\n\n==== Atualizar senha (código (" + usuario.getCodigo() + ") === ");
        usuario.setSenha(DAO.toMD5("pablo"));
        usuarioDAO.update(usuario);

        System.out.println("\n\n==== Testando autenticação ===");
        System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", DAO.toMD5("pablo")));

        System.out.println("\n\n==== Invadir usando SQL Injection ===");
        System.out.println("Usuário (" + usuario.getLogin() + "): " + usuarioDAO.autenticar("pablo", "x' OR 'x' LIKE 'x"));

        System.out.println("\n\n==== Mostrar usuários ordenados por código === ");
        usuarios = usuarioDAO.getOrderByCodigo();
        for (Usuario u: usuarios) {
            System.out.println(u.toString());
        }

        System.out.println("\n\n==== Excluir usuário (código " + usuario.getCodigo() + ") === ");
        usuarioDAO.delete(usuario.getCodigo());

        System.out.println("\n\n==== Mostrar usuários ordenados por login === ");
        usuarios = usuarioDAO.getOrderByLogin();
        for (Usuario u: usuarios) {
            System.out.println(u.toString());
        }
    }
}
